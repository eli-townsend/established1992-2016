# Winston Responsive Theme

## Images sources:
   
### Banner: 
    * big-data.jpg: https://picjumbo.imgix.net/DSC00083.jpg?q=40&w=1650&sharp=30 - Photo by picjumbo.com
### Headshots
    * jane-doe.jpg: http://www.gratisography.com/pictures/361_1.jpg
    * jackie-doe.jpg: http://www.gratisography.com/pictures/288_1.jpg
    * john-doe.jpg: http://www.gratisography.com/pictures/220_1.jpg
 
### License: 
All gratisography.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/ 	

### Bootstrap
Resource URI: http://getbootstrap.com/
Copyright: 2011-2014 Twitter, Inc
License: MIT
License URI: http://opensource.org/licenses/MIT

### Animate On Scroll (AOS)
Resource URI: https://michalsnik.github.io/aos/
Copyright: 2015 Michał Sajnóg
License: MIT
License URI: http://opensource.org/licenses/MIT

### Snazzy Maps
Resource URI: https://snazzymaps.com/
Copyright: None
License: CC0 1.0
License URI: https://creativecommons.org/publicdomain/zero/1.0/

### Font Awesome
Resource URI: http://fontawesome.io/
Version: 4.2.0
License: MIT
License URI: https://opensource.org/licenses/mit-license.html
